
import { buildTriadKey, buildPatternKey, FoodLike } from "./mealHistory";

export type MealHistoryEntryLike = {
  dayNumber: number;
  mealType: string;
  foodIds: string[];
  triadKey: string;
  patternKey: string;
};

export const WEEKLY_MAX_FREQUENCY: Record<string, number> = {
  chicken_breast: 3,
  poached_chicken_plain: 3,
  white_fish: 3,
  salmon: 2,
  brown_rice: 3,
  brown_rice_cooked: 3,
  quinoa: 3,
  quinoa_cooked: 3,
  barley: 3,
  barley_cooked: 3,
  broccoli: 3,
  cauliflower: 3,
  lentils: 3,
  lentils_cooked: 3,
  sweet_potato: 3,
  sweet_potato_mash_plain: 3,
  arrowroot_boiled_soft: 3,
};

export function foodRepetitionPenalty(
  currentFoodIds: string[],
  history: MealHistoryEntryLike[]
): number {
  let penalty = 0;

  for (let i = 0; i < history.length; i++) {
    const h = history[history.length - 1 - i];
    const weight = Math.max(1, 4 - i); // most recent hurts more

    for (const id of currentFoodIds) {
      if (h.foodIds.includes(id)) {
        penalty += 1.5 * weight;
      }
    }
  }

  return penalty;
}

export function triadRepetitionPenalty(
  triadKey: string,
  mealType: string,
  history: MealHistoryEntryLike[]
): number {
  let penalty = 0;

  for (let i = 0; i < history.length; i++) {
    const h = history[history.length - 1 - i];
    const weight = Math.max(1, 4 - i);

    if (h.mealType === mealType && h.triadKey === triadKey) {
      penalty += 8 * weight;
    } else if (h.triadKey === triadKey) {
      penalty += 5 * weight;
    }
  }

  return penalty;
}

export function patternRepetitionPenalty(
  patternKey: string,
  mealType: string,
  history: MealHistoryEntryLike[]
): number {
  let penalty = 0;

  for (let i = 0; i < history.length; i++) {
    const h = history[history.length - 1 - i];
    const weight = Math.max(1, 3 - i);

    if (h.mealType === mealType && h.patternKey === patternKey) {
      penalty += 3 * weight;
    }
  }

  return penalty;
}

export function weeklyFrequencyPenalty(
  currentFoodIds: string[],
  history: MealHistoryEntryLike[]
): number {
  const counts: Record<string, number> = {};

  for (const h of history) {
    for (const id of h.foodIds) {
      counts[id] = (counts[id] ?? 0) + 1;
    }
  }

  let penalty = 0;

  for (const id of currentFoodIds) {
    const used = counts[id] ?? 0;
    const max = WEEKLY_MAX_FREQUENCY[id];
    if (max !== undefined && used >= max) {
      penalty += 25;
    }
  }

  return penalty;
}

export function totalRotationPenalty(params: {
  currentFoodIds: string[];
  triadKey: string;
  patternKey: string;
  mealType: string;
  history: MealHistoryEntryLike[];
}): number {
  return (
    foodRepetitionPenalty(params.currentFoodIds, params.history) +
    triadRepetitionPenalty(params.triadKey, params.mealType, params.history) +
    patternRepetitionPenalty(params.patternKey, params.mealType, params.history) +
    weeklyFrequencyPenalty(params.currentFoodIds, params.history)
  );
}

export function isRecentTriadRepeat(
  triadKey: string,
  mealType: string,
  history: MealHistoryEntryLike[],
  recentWindow: number = 6
): boolean {
  const recent = history.slice(-recentWindow);
  return recent.some((h) => h.mealType === mealType && h.triadKey === triadKey);
}

export function augmentScoreWithRotation(params: {
  baseScore: number;
  mealType: string;
  proposedItems: Array<{ food_id?: string; foodId?: string }>;
  foodIndex: FoodLike[];
  history: MealHistoryEntryLike[];
}): number {
  const currentFoodIds = params.proposedItems
    .map((i) => i.food_id ?? i.foodId ?? "")
    .filter(Boolean);

  const triadKey = buildTriadKey(params.proposedItems, params.foodIndex);
  const patternKey = buildPatternKey(params.proposedItems, params.foodIndex);

  const rotationPenalty = totalRotationPenalty({
    currentFoodIds,
    triadKey,
    patternKey,
    mealType: params.mealType,
    history: params.history,
  });

  return params.baseScore + rotationPenalty;
}

export type SolveMealFn<TMeal> = (opts?: {
  bannedFoodIds?: string[];
  penalizedFoodIds?: string[];
}) => TMeal;

export type MealResultLike = {
  mealType: string;
  items: Array<{ food_id?: string; foodId?: string }>;
  score?: number;
};

export function solveWithRetryForRotation<TMeal extends MealResultLike>(params: {
  solveMeal: SolveMealFn<TMeal>;
  mealType: string;
  history: MealHistoryEntryLike[];
  foodIndex: FoodLike[];
}): TMeal {
  const first = params.solveMeal();

  const firstTriad = buildTriadKey(first.items, params.foodIndex);

  if (!isRecentTriadRepeat(firstTriad, params.mealType, params.history)) {
    return first;
  }

  const penalizedFoodIds = first.items
    .map((x) => x.food_id ?? x.foodId ?? "")
    .filter(Boolean);

  const retry = params.solveMeal({
    penalizedFoodIds,
  });

  const retryTriad = buildTriadKey(retry.items, params.foodIndex);

  const firstRepeat = isRecentTriadRepeat(firstTriad, params.mealType, params.history);
  const retryRepeat = isRecentTriadRepeat(retryTriad, params.mealType, params.history);

  if (firstRepeat && !retryRepeat) return retry;

  const firstScore = first.score ?? Number.MAX_SAFE_INTEGER;
  const retryScore = retry.score ?? Number.MAX_SAFE_INTEGER;

  return retryScore <= firstScore ? retry : first;
}
