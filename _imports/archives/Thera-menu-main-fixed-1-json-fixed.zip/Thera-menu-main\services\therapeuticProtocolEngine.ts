
export interface ClinicalProtocol {
  id: string;
  code: string;
  name: string;
  description: string;
  clinical_priority: number;
}

export interface ProtocolRuleTarget {
  id: string;
  protocol_id: string;
  nutrient_key: string;
  min_value?: number;
  max_value?: number;
  target_value?: number;
  unit: string;
  clinical_rationale: string;
}

export interface ProtocolFoodRule {
  id: string;
  protocol_id: string;
  rule_type: 'EXCLUDE' | 'LIMIT' | 'ENCOURAGE' | 'REQUIRED';
  category: string;
  tag_match: string;
  max_frequency_per_week?: number;
  clinical_rationale: string;
}

export interface ProtocolComponentSlot {
  id: string;
  protocol_id: string;
  meal_type: 'BREAKFAST' | 'LUNCH' | 'DINNER' | 'SNACK';
  slot_name: string;
  required: boolean;
  display_order: number;
}

export interface ProtocolSlotCandidate {
  id: string;
  slot_id: string;
  food_category: string;
  texture_compatibility: string[];
  portion_size: string;
}

// DATA CONFIGURATION LAYER
export const THERAPEUTIC_PROTOCOLS: ClinicalProtocol[] = [
  {
    id: "p-001",
    code: "GASTRIC_ACUTE",
    name: "Acute Gastric Management",
    description: "Protocol for active peptic ulcers or severe gastritis.",
    clinical_priority: 1
  },
  {
    id: "p-002",
    code: "RENAL_CKD3",
    name: "CKD Stage 3 (Non-Dialysis)",
    description: "Protein and phosphorus controlled protocol for CKD.",
    clinical_priority: 2
  }
];

export const PROTOCOL_RULE_TARGETS: ProtocolRuleTarget[] = [
  {
    id: "rt-001",
    protocol_id: "p-001",
    nutrient_key: "sodiumMg",
    max_value: 2000,
    unit: "mg",
    clinical_rationale: "Reduce fluid retention and gastric irritation."
  },
  {
    id: "rt-002",
    protocol_id: "p-001",
    nutrient_key: "fiberG",
    max_value: 15,
    unit: "g",
    clinical_rationale: "Low residue to minimize gastric mechanical work."
  }
];

export const PROTOCOL_FOOD_RULES: ProtocolFoodRule[] = [
  {
    id: "fr-001",
    protocol_id: "p-001",
    rule_type: "EXCLUDE",
    category: "BEVERAGE",
    tag_match: "Caffeine",
    clinical_rationale: "Caffeine stimulates gastric acid secretion."
  },
  {
    id: "fr-002",
    protocol_id: "p-001",
    rule_type: "EXCLUDE",
    category: "SPICE",
    tag_match: "Spicy",
    clinical_rationale: "Direct mucosal irritant."
  }
];

export const PROTOCOL_COMPONENT_SLOTS: ProtocolComponentSlot[] = [
  {
    id: "pcs-001",
    protocol_id: "p-001",
    meal_type: "BREAKFAST",
    slot_name: "Gentle Starch",
    required: true,
    display_order: 1
  },
  {
    id: "pcs-002",
    protocol_id: "p-001",
    meal_type: "BREAKFAST",
    slot_name: "Lean Protein",
    required: true,
    display_order: 2
  }
];

export const PROTOCOL_SLOT_CANDIDATES: ProtocolSlotCandidate[] = [
  {
    id: "psc-001",
    slot_id: "pcs-001",
    food_category: "Grain",
    texture_compatibility: ["Soft", "Pureed"],
    portion_size: "150g"
  }
];

// ADAPTER LAYER
export const getProtocolByCode = (code: string) => {
  return THERAPEUTIC_PROTOCOLS.find(p => p.code === code);
};

export const getProtocolRules = (protocolId: string) => {
  return {
    targets: PROTOCOL_RULE_TARGETS.filter(t => t.protocol_id === protocolId),
    foodRules: PROTOCOL_FOOD_RULES.filter(r => r.protocol_id === protocolId),
    slots: PROTOCOL_COMPONENT_SLOTS.filter(s => s.protocol_id === protocolId)
  };
};
