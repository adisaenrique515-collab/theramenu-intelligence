
export type MealHistoryEntry = {
  dayNumber: number;
  mealType: string;
  foodIds: string[];
  triadKey: string;
  patternKey: string;
};

export type MealItemLike = {
  food_id?: string;
  foodId?: string;
};

export type FoodLike = {
  food_id?: string;
  foodId?: string;
  category: string;
};

function getFoodId(x: { food_id?: string; foodId?: string }): string {
  return x.food_id ?? x.foodId ?? "";
}

export function buildTriadKey(
  items: MealItemLike[],
  foodIndex: FoodLike[]
): string {
  let starch = "NONE";
  let protein = "NONE";
  let veg = "NONE";

  for (const item of items) {
    const id = getFoodId(item);
    const food = foodIndex.find(
      (f) => getFoodId(f) === id
    );
    if (!food) continue;

    if (["grain", "starch", "legume"].includes(food.category) && starch === "NONE") {
      starch = id;
      continue;
    }

    if (["protein", "dairy"].includes(food.category) && protein === "NONE") {
      protein = id;
      continue;
    }

    if (food.category === "vegetable" && veg === "NONE") {
      veg = id;
      continue;
    }
  }

  return `${starch}|${protein}|${veg}`;
}

export function buildPatternKey(
  items: MealItemLike[],
  foodIndex: FoodLike[]
): string {
  const cats: string[] = [];

  for (const item of items) {
    const id = getFoodId(item);
    const food = foodIndex.find(
      (f) => getFoodId(f) === id
    );
    if (!food) continue;
    cats.push(food.category);
  }

  return cats.sort().join("|");
}

export function buildMealHistoryEntry(params: {
  dayNumber: number;
  mealType: string;
  items: MealItemLike[];
  foodIndex: FoodLike[];
}): MealHistoryEntry {
  const foodIds = params.items
    .map((i) => getFoodId(i))
    .filter(Boolean);

  return {
    dayNumber: params.dayNumber,
    mealType: params.mealType,
    foodIds,
    triadKey: buildTriadKey(params.items, params.foodIndex),
    patternKey: buildPatternKey(params.items, params.foodIndex),
  };
}

export function trimMealHistory(
  history: MealHistoryEntry[],
  maxEntries: number = 42 // 7 days * 6 meals
): MealHistoryEntry[] {
  if (history.length <= maxEntries) return history;
  return history.slice(history.length - maxEntries);
}
