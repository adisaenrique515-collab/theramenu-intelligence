import { WeeklyTherapeuticPlan, MealPlan, MealSlot } from "../types";
import { getClinicalRules, ClinicalConditionRule } from "./clinicalDatabase";

export interface ValidationResult {
  passed: boolean;
  issues: string[];
}

export function validateWeeklyPlan(plan: WeeklyTherapeuticPlan): ValidationResult {
  const issues: string[] = [];
  const rules = getClinicalRules(plan.diagnosis);

  // 1. Validate Clinical Constraints (Forbidden Tags)
  plan.days.forEach(day => {
    day.meals.forEach(meal => {
      validateMealForbiddenTags(meal, rules, day.dayName, issues);
      validateMealSlots(meal, rules, day.dayName, issues);
      validateOperationalMetadata(meal, day.dayName, issues);
    });
  });

  // 2. Validate Structure
  if (!plan.days || plan.days.length !== 7) {
    issues.push("Plan does not contain exactly 7 days.");
  }

  return {
    passed: issues.length === 0,
    issues
  };
}

function validateMealForbiddenTags(meal: MealPlan, rules: ClinicalConditionRule, dayName: string, issues: string[]) {
  const forbidden = rules.forbidden_tags.map(t => t.toLowerCase());
  
  const checkItem = (itemName: string, context: string) => {
    const lowerName = itemName.toLowerCase();
    forbidden.forEach(tag => {
      if (lowerName.includes(tag)) {
        issues.push(`[${dayName} - ${meal.mealType}] Item '${itemName}' contains forbidden tag: '${tag}'`);
      }
    });
  };

  if (meal.slots) {
    meal.slots.forEach(slot => {
      if (slot.item?.name) {
        checkItem(slot.item.name, slot.slotName);
      }
    });
  } else if (meal.items) {
    meal.items.forEach(item => {
      checkItem(item.description, "Legacy Item");
    });
  }
}

function validateMealSlots(meal: MealPlan, rules: ClinicalConditionRule, dayName: string, issues: string[]) {
  if (!meal.slots) return; // Skip if using legacy items (though we prefer slots now)

  const mealTypeKey = meal.mealType.toLowerCase() as keyof typeof rules.slots;
  const expectedSlots = rules.slots[mealTypeKey];

  if (!expectedSlots) {
    // Maybe a snack or other meal type not strictly defined, skip strict slot check or log warning
    return;
  }

  // Check if all expected slots are present
  expectedSlots.forEach(expected => {
    const found = meal.slots?.find(s => s.slotName === expected.name);
    if (!found) {
      issues.push(`[${dayName} - ${meal.mealType}] Missing required slot: '${expected.name}'`);
    } else if (found.status === 'EMPTY' || !found.item) {
      issues.push(`[${dayName} - ${meal.mealType}] Slot '${expected.name}' is EMPTY`);
    } else {
      // Validate Portion Format
      if (!found.item.portion || !found.item.portion.match(/\d+/)) {
         issues.push(`[${dayName} - ${meal.mealType}] Slot '${expected.name}' has invalid portion format: '${found.item.portion}'`);
      }
    }
  });
}

function validateOperationalMetadata(meal: MealPlan, dayName: string, issues: string[]) {
  if (!meal.slots) return;

  meal.slots.forEach(slot => {
    if (slot.item) {
      // Check if operational metadata is missing for hot/cold items
      // This is a heuristic: if it's a protein or starch, it likely needs a temp.
      // We can check if the 'operational' object exists.
      if (!slot.item.operational) {
         // Not necessarily an error, but a warning for hospital grade
         // issues.push(`[${dayName} - ${meal.mealType}] Slot '${slot.slotName}' missing operational metadata`);
      } else {
        const { hotHoldingTemp, coldHoldingTemp, serviceTemp } = slot.item.operational;
        if (!hotHoldingTemp && !coldHoldingTemp) {
             // issues.push(`[${dayName} - ${meal.mealType}] Slot '${slot.slotName}' missing holding temp`);
        }
        if (!serviceTemp) {
             issues.push(`[${dayName} - ${meal.mealType}] Slot '${slot.slotName}' missing service temp`);
        }
      }
    }
  });
}
