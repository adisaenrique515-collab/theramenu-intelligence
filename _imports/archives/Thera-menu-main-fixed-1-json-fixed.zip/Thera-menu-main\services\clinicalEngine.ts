/* ============================================================================
TheraMenu Master Clinical Nutrition Engine
Version: v3.0
============================================================================ */

export type Sex = "male" | "female";
export type DiagnosisCode = "GENERAL_WELLNESS" | "GENERAL_HOSPITAL" | "T2DM" | "HTN" | "CARDIAC" | "RENAL_STAGE_3" | "RENAL_STAGE_4" | "LIVER_SUPPORT" | "PEPTIC_ULCER" | "GASTRIC" | "H_PYLORI" | "LOW_FAT" | "HIGH_PROTEIN" | "POST_OP_SOFT" | "MSD";
export type NutritionGoal = "maintenance" | "weight_loss" | "weight_gain" | "muscle_gain" | "glycemic_control" | "cardiac_protection" | "renal_protection" | "gut_healing" | "clinical_repletion" | "clinical_recovery";
export type Somatotype = "endomorph" | "mesomorph" | "ectomorph" | "unknown";
export type TextureLevel = "regular" | "soft" | "minced" | "pureed" | "liquid";
export type MealType = "breakfast" | "morning_snack" | "lunch" | "afternoon_snack" | "dinner" | "bedtime_snack";
export type FoodCategory = "grain" | "protein" | "vegetable" | "fruit" | "dairy" | "fat" | "beverage" | "legume" | "starch" | "broth";

export interface PatientProfile {
  id?: string;
  age: number;
  sex: Sex;
  weightKg: number;
  heightCm: number;
  diagnosis: DiagnosisCode;
  goal: NutritionGoal;
  somatotype: Somatotype;
  textureLevel: TextureLevel;
  activityFactor?: number;
  stressFactor?: number;
  calorieOverride?: number;
  proteinOverrideGPerKg?: number;
  sodiumOverrideMg?: number;
  fluidOverrideMl?: number;
  mealCount?: 3 | 4 | 5 | 6;
}

export interface FoodItem {
  id: string;
  name: string;
  category: FoodCategory;
  unit: "g" | "ml" | "piece";
  servingBasis: "per100g" | "per100ml" | "perPiece";
  defaultServing: number;
  kcal: number;
  carbsG: number;
  proteinG: number;
  fatG: number;
  fiberG: number;
  sugarG?: number;
  sodiumMg: number;
  potassiumMg?: number;
  phosphorusMg?: number;
  cholesterolMg?: number;
  saturatedFatG?: number;
  fluidMl?: number;
  glycemicIndex?: number;
  mealTags?: MealType[];
  textureTags?: TextureLevel[];
  tags: string[];
  contraindicatedFor?: DiagnosisCode[];
}

export interface NutrientVector {
  caloriesKcal: number;
  carbsG: number;
  proteinG: number;
  fatG: number;
  fiberG: number;
  sodiumMg: number;
  potassiumMg: number;
  phosphorusMg: number;
  cholesterolMg: number;
  saturatedFatG: number;
  sugarG: number;
  fluidMl: number;
}

export interface ClinicalTargets extends NutrientVector {
  fiberGMin: number;
  sodiumMgMax: number;
  potassiumMgMax?: number;
  phosphorusMgMax?: number;
  cholesterolMgMax?: number;
  saturatedFatGMax?: number;
  sugarGMax?: number;
  fluidMlTarget?: number;
  giPreferredMax?: number;
}

export interface MealPlan {
  mealType: MealType;
  items: { foodId: string; foodName: string; quantity: number; unit: string }[];
  totals: NutrientVector;
  warnings: string[];
}

export interface DailyPlan {
  dayNumber: number;
  dailyTargets: ClinicalTargets;
  meals: MealPlan[];
  totals: NutrientVector;
  warnings: string[];
}

export interface WeeklyPlan {
  patient: PatientProfile;
  days: DailyPlan[];
}

const round2 = (n: number) => Math.round(n * 100) / 100;

export function calculateBMR(profile: PatientProfile): number {
  const { weightKg, heightCm, age, sex } = profile;
  if (sex === "male") {
    return 10 * weightKg + 6.25 * heightCm - 5 * age + 5;
  } else {
    return 10 * weightKg + 6.25 * heightCm - 5 * age - 161;
  }
}

export function getClinicalTargets(profile: PatientProfile): ClinicalTargets {
  const bmr = calculateBMR(profile);
  const af = profile.activityFactor || 1.2;
  const sf = profile.stressFactor || 1.0;
  let calories = profile.calorieOverride || bmr * af * sf;

  // Goal adjustments
  if (profile.goal === "weight_loss") calories -= 500;
  if (profile.goal === "weight_gain" || profile.goal === "muscle_gain") calories += 500;
  if (profile.goal === "clinical_recovery") calories *= 1.2;

  // Default distribution
  let pPct = 0.2, cPct = 0.5, fPct = 0.3;
  let sodiumMax = profile.sodiumOverrideMg || 2300;
  let fiberMin = 25;
  let fluidTarget = profile.fluidOverrideMl || profile.weightKg * 30;

  const diag = profile.diagnosis;

  if (diag === "T2DM") {
    cPct = 0.4; pPct = 0.25; fPct = 0.35;
    fiberMin = 30;
  } else if (diag === "HTN" || diag === "CARDIAC") {
    sodiumMax = 1500;
    fPct = 0.25; cPct = 0.55;
  } else if (diag === "RENAL_STAGE_3" || diag === "RENAL_STAGE_4") {
    pPct = diag === "RENAL_STAGE_4" ? 0.12 : 0.15;
    sodiumMax = 1500;
    fluidTarget = Math.min(fluidTarget, 1500);
  } else if (diag === "LIVER_SUPPORT") {
    pPct = 0.25;
    sodiumMax = 1800;
  } else if (diag === "PEPTIC_ULCER" || diag === "GASTRIC" || diag === "H_PYLORI") {
    fiberMin = 20; // Low fiber for acute phase
    calories *= 1.1; // Extra for healing
  } else if (diag === "HIGH_PROTEIN") {
    pPct = 0.35; cPct = 0.35; fPct = 0.3;
  } else if (diag === "LOW_FAT") {
    fPct = 0.15; cPct = 0.65;
  }

  return {
    caloriesKcal: round2(calories),
    carbsG: round2((calories * cPct) / 4),
    proteinG: round2((calories * pPct) / 4),
    fatG: round2((calories * fPct) / 9),
    fiberG: fiberMin,
    fiberGMin: fiberMin,
    sodiumMg: sodiumMax,
    sodiumMgMax: sodiumMax,
    potassiumMg: 2000,
    phosphorusMg: 1000,
    cholesterolMg: 200,
    saturatedFatG: round2((calories * 0.07) / 9),
    sugarG: 30,
    fluidMl: fluidTarget,
    fluidMlTarget: fluidTarget,
  };
}

export const FOOD_DB: FoodItem[] = [
  { id: "oats", name: "Rolled Oats", category: "grain", unit: "g", servingBasis: "per100g", defaultServing: 40, kcal: 389, carbsG: 66, proteinG: 17, fatG: 7, fiberG: 10, sodiumMg: 2, tags: ["low_gi"], textureTags: ["regular", "soft"] },
  { id: "chicken", name: "Chicken Breast", category: "protein", unit: "g", servingBasis: "per100g", defaultServing: 120, kcal: 165, carbsG: 0, proteinG: 31, fatG: 3.6, fiberG: 0, sodiumMg: 74, tags: ["lean"], textureTags: ["regular", "soft", "minced"] },
  { id: "broccoli", name: "Broccoli", category: "vegetable", unit: "g", servingBasis: "per100g", defaultServing: 100, kcal: 34, carbsG: 7, proteinG: 2.8, fatG: 0.4, fiberG: 2.6, sodiumMg: 33, tags: ["fiber"], textureTags: ["regular", "soft"] },
  { id: "brown_rice", name: "Brown Rice", category: "grain", unit: "g", servingBasis: "per100g", defaultServing: 150, kcal: 111, carbsG: 23, proteinG: 2.6, fatG: 0.9, fiberG: 1.8, sodiumMg: 5, tags: ["whole_grain"], textureTags: ["regular", "soft"] },
  { id: "egg", name: "Whole Egg", category: "protein", unit: "piece", servingBasis: "perPiece", defaultServing: 2, kcal: 70, carbsG: 0.4, proteinG: 6, fatG: 5, fiberG: 0, sodiumMg: 70, tags: ["protein"], textureTags: ["regular", "soft", "minced"] },
  { id: "apple", name: "Apple", category: "fruit", unit: "g", servingBasis: "per100g", defaultServing: 150, kcal: 52, carbsG: 14, proteinG: 0.3, fatG: 0.2, fiberG: 2.4, sodiumMg: 1, tags: ["fruit"], textureTags: ["regular", "soft"] },
  { id: "yogurt", name: "Greek Yogurt", category: "dairy", unit: "g", servingBasis: "per100g", defaultServing: 150, kcal: 59, carbsG: 3.6, proteinG: 10, fatG: 0.4, fiberG: 0, sodiumMg: 36, tags: ["probiotic"], textureTags: ["regular", "soft", "liquid"] },
  { id: "salmon", name: "Salmon", category: "protein", unit: "g", servingBasis: "per100g", defaultServing: 120, kcal: 208, carbsG: 0, proteinG: 20, fatG: 13, fiberG: 0, sodiumMg: 59, tags: ["omega3"], textureTags: ["regular", "soft"] },
  { id: "spinach", name: "Spinach", category: "vegetable", unit: "g", servingBasis: "per100g", defaultServing: 100, kcal: 23, carbsG: 3.6, proteinG: 2.9, fatG: 0.4, fiberG: 2.2, sodiumMg: 79, tags: ["iron"], textureTags: ["regular", "soft", "minced"] },
  { id: "olive_oil", name: "Olive Oil", category: "fat", unit: "g", servingBasis: "per100g", defaultServing: 10, kcal: 884, carbsG: 0, proteinG: 0, fatG: 100, fiberG: 0, sodiumMg: 0, tags: ["healthy_fat"], textureTags: ["regular", "soft", "liquid"] },
  { id: "congee", name: "Rice Congee", category: "broth", unit: "g", servingBasis: "per100g", defaultServing: 250, kcal: 37, carbsG: 8, proteinG: 0.7, fatG: 0.1, fiberG: 0.2, sodiumMg: 5, tags: ["soft"], textureTags: ["soft", "minced", "pureed", "liquid"] },
  { id: "white_fish", name: "White Fish Steamed", category: "protein", unit: "g", servingBasis: "per100g", defaultServing: 120, kcal: 110, carbsG: 0, proteinG: 23, fatG: 1.5, fiberG: 0, sodiumMg: 80, tags: ["lean"], textureTags: ["regular", "soft", "minced"] },
  { id: "mashed_potato", name: "Mashed Potato", category: "starch", unit: "g", servingBasis: "per100g", defaultServing: 150, kcal: 88, carbsG: 17, proteinG: 2, fatG: 1.5, fiberG: 2, sodiumMg: 10, tags: ["soft"], textureTags: ["soft", "minced", "pureed"] },
  { id: "banana", name: "Banana", category: "fruit", unit: "g", servingBasis: "per100g", defaultServing: 100, kcal: 89, carbsG: 23, proteinG: 1.1, fatG: 0.3, fiberG: 2.6, sodiumMg: 1, tags: ["soft"], textureTags: ["regular", "soft", "minced", "pureed"] },
  { id: "vegetable_broth", name: "Vegetable Broth", category: "broth", unit: "ml", servingBasis: "per100ml", defaultServing: 200, kcal: 15, carbsG: 3, proteinG: 0.5, fatG: 0.1, fiberG: 0, sodiumMg: 150, tags: ["liquid"], textureTags: ["liquid"] },
];

import { buildMealHistoryEntry, trimMealHistory, MealHistoryEntry } from "./mealHistory";
import { solveWithRetryForRotation, augmentScoreWithRotation } from "./rotationPenalty";

export function generateMealPlan(mealType: MealType, targets: Partial<NutrientVector>, texture: TextureLevel, history: MealHistoryEntry[] = []): MealPlan {
  const eligible = FOOD_DB.filter(f => !f.textureTags || f.textureTags.includes(texture));
  
  // We wrap the existing logic in a solver function that can be called with retries
  const solve = (opts?: { penalizedFoodIds?: string[] }) => {
    const items: MealPlan["items"] = [];
    const totals = { caloriesKcal: 0, carbsG: 0, proteinG: 0, fatG: 0, fiberG: 0, sodiumMg: 0, potassiumMg: 0, phosphorusMg: 0, cholesterolMg: 0, saturatedFatG: 0, sugarG: 0, fluidMl: 0 };

    // Helper to add food
    const addFood = (f: FoodItem) => {
      const qty = f.defaultServing;
      items.push({ foodId: f.id, foodName: f.name, quantity: qty, unit: f.unit });
      const mult = f.servingBasis === "perPiece" ? qty : qty / 100;
      totals.caloriesKcal += f.kcal * mult;
      totals.carbsG += f.carbsG * mult;
      totals.proteinG += f.proteinG * mult;
      totals.fatG += f.fatG * mult;
      totals.fiberG += f.fiberG * mult;
      totals.sodiumMg += f.sodiumMg * mult;
      totals.fluidMl += (f.fluidMl || 0) * (f.servingBasis === "perPiece" ? qty : (f.unit === "ml" ? qty : mult));
    };

    // Selection logic based on meal type
    if (mealType === "breakfast") {
      // Simple selection logic: find first available. 
      // In a real solver we'd iterate over candidates and pick best score.
      // Here we just filter out penalized if possible.
      let grainPool = eligible.filter(f => f.category === "grain" || f.category === "broth");
      if (opts?.penalizedFoodIds) {
        const filtered = grainPool.filter(f => !opts.penalizedFoodIds?.includes(f.id));
        if (filtered.length > 0) grainPool = filtered;
      }
      const grain = grainPool[0];

      let proteinPool = eligible.filter(f => f.category === "protein" || f.category === "dairy");
      if (opts?.penalizedFoodIds) {
        const filtered = proteinPool.filter(f => !opts.penalizedFoodIds?.includes(f.id));
        if (filtered.length > 0) proteinPool = filtered;
      }
      const protein = proteinPool[0];

      if (grain) addFood(grain);
      if (protein) addFood(protein);
    } else if (mealType === "lunch" || mealType === "dinner") {
      let proteinPool = eligible.filter(f => f.category === "protein");
      if (opts?.penalizedFoodIds) {
        const filtered = proteinPool.filter(f => !opts.penalizedFoodIds?.includes(f.id));
        if (filtered.length > 0) proteinPool = filtered;
      }
      const protein = proteinPool[0];

      let starchPool = eligible.filter(f => f.category === "grain" || f.category === "starch");
      if (opts?.penalizedFoodIds) {
        const filtered = starchPool.filter(f => !opts.penalizedFoodIds?.includes(f.id));
        if (filtered.length > 0) starchPool = filtered;
      }
      const starch = starchPool[0];

      let vegPool = eligible.filter(f => f.category === "vegetable");
      if (opts?.penalizedFoodIds) {
        const filtered = vegPool.filter(f => !opts.penalizedFoodIds?.includes(f.id));
        if (filtered.length > 0) vegPool = filtered;
      }
      const veg = vegPool[0];

      if (protein) addFood(protein);
      if (starch) addFood(starch);
      if (veg) addFood(veg);
    } else {
      // Snacks
      let snackPool = eligible.filter(f => f.category === "fruit" || f.category === "dairy");
      if (opts?.penalizedFoodIds) {
        const filtered = snackPool.filter(f => !opts.penalizedFoodIds?.includes(f.id));
        if (filtered.length > 0) snackPool = filtered;
      }
      const snack = snackPool[0];
      if (snack) addFood(snack);
    }

    // Round totals
    Object.keys(totals).forEach(k => {
      (totals as any)[k] = round2((totals as any)[k]);
    });

    // Score augmentation
    const baseScore = 0; // Simple placeholder for nutrient deviation
    const score = augmentScoreWithRotation({
      baseScore,
      mealType,
      proposedItems: items,
      foodIndex: FOOD_DB,
      history
    });

    return { mealType, items, totals, warnings: [], score };
  };

  return solveWithRetryForRotation({
    solveMeal: solve,
    mealType,
    history,
    foodIndex: FOOD_DB
  });
}

export function generateWeeklyPlan(profile: PatientProfile): WeeklyPlan {
  const targets = getClinicalTargets(profile);
  const days: DailyPlan[] = [];
  const mealCount = profile.mealCount || 3;
  let history: MealHistoryEntry[] = [];

  for (let i = 1; i <= 7; i++) {
    const meals: MealPlan[] = [];
    
    const mealTypes: MealType[] = ["breakfast", "lunch", "dinner"];
    if (mealCount >= 4) mealTypes.push("afternoon_snack");
    if (mealCount >= 5) mealTypes.push("morning_snack");
    if (mealCount >= 6) mealTypes.push("bedtime_snack");

    for (const mt of mealTypes) {
      const m = generateMealPlan(mt, targets, profile.textureLevel, history);
      meals.push(m);
      
      // Update history
      history.push(buildMealHistoryEntry({
        dayNumber: i,
        mealType: mt,
        items: m.items,
        foodIndex: FOOD_DB
      }));
      history = trimMealHistory(history);
    }

    const dayTotals = meals.reduce((acc, m) => {
      const mTotals = m.totals || { caloriesKcal: 0, carbsG: 0, proteinG: 0, fatG: 0, fiberG: 0, sodiumMg: 0, fluidMl: 0 };
      return {
        caloriesKcal: acc.caloriesKcal + (mTotals.caloriesKcal || 0),
        carbsG: acc.carbsG + (mTotals.carbsG || 0),
        proteinG: acc.proteinG + (mTotals.proteinG || 0),
        fatG: acc.fatG + (mTotals.fatG || 0),
        fiberG: acc.fiberG + (mTotals.fiberG || 0),
        sodiumMg: acc.sodiumMg + (mTotals.sodiumMg || 0),
        potassiumMg: 0, 
        phosphorusMg: 0, 
        cholesterolMg: 0, 
        saturatedFatG: 0, 
        sugarG: 0, 
        fluidMl: acc.fluidMl + (mTotals.fluidMl || 0)
      };
    }, { caloriesKcal: 0, carbsG: 0, proteinG: 0, fatG: 0, fiberG: 0, sodiumMg: 0, potassiumMg: 0, phosphorusMg: 0, cholesterolMg: 0, saturatedFatG: 0, sugarG: 0, fluidMl: 0 });

    days.push({ dayNumber: i, dailyTargets: targets, meals, totals: dayTotals, warnings: [] });
  }
  return { patient: profile, days };
}
