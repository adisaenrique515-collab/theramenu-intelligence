
export interface OperationalMetadata {
  hotHoldingTemp?: string;
  coldHoldingTemp?: string;
  transportTemp?: string;
  serviceTemp?: string;
  handlingNotes?: string;
}

export interface ClinicalIntelligence {
  structuralStability: {
    fsdi: number;
    acidBalance: number;
    fragilityRisk: 'LOW' | 'MEDIUM' | 'HIGH';
  };
  yieldConversion: {
    rawToTrimPercent: number;
    trimToCookPercent: number;
    portionScalingFactor: number;
  };
  costIntelligence: {
    costPerPortion: number;
    contributionMargin: number;
    foodCostPercent: number;
  };
  menuClassification: 'STAR' | 'PUZZLE' | 'PLOWHORSE' | 'DOG';
  procurementForecast: string;
}

export interface SlotItem {
  name: string;
  portion: string; // Standard portion (e.g., "120g")
  minPortion?: string;
  maxPortion?: string;
  therapeuticOverride?: string; // e.g., "Pureed for Dysphagia"
  operational?: OperationalMetadata;
  intelligence?: ClinicalIntelligence;
}

export interface MealSlot {
  slotName: string; // e.g., "Base Carbohydrate", "Protein"
  item: SlotItem | null; // The item filling the slot
  status: 'FILLED' | 'EMPTY' | 'SUBSTITUTED';
  substitutionNote?: string;
}

export interface MenuItem {
  description: string;
  servingSize: string;
}

export interface TherapeuticConstraints {
  exclude: string[];
  prioritize: string[];
  textureLevel: string; // IDDSI Standards
  nutrientTargets?: string;
}

export type OperatorType = ">=" | "<=" | "==" | ">" | "<";

export interface FacilityStandard {
  key: string;
  operator: OperatorType;
  value: number;
  unit: string;
  note?: string;
}

export interface HospitalMenusStandards {
  hotHolding: string;
  servingHotFood: string;
  coldHolding: string;
  servingColdFood: string;
  boosting: string;
  vehicle: string;
  standardsList?: FacilityStandard[];
}

export interface MealPlan {
  mealType: "Breakfast" | "Lunch" | "Dinner";
  items?: MenuItem[]; // Deprecated in favor of slots
  slots?: MealSlot[]; // New structured format
  dietaryLabel: string; // e.g., "ONCOLOGY - HIGH PROTEIN"
}

export interface NutrientVector {
  caloriesKcal: number;
  carbsG: number;
  proteinG: number;
  fatG: number;
  fiberG: number;
  sodiumMg: number;
  potassiumMg: number;
  phosphorusMg: number;
  cholesterolMg: number;
  saturatedFatG: number;
  sugarG: number;
  fluidMl: number;
}

export interface ClinicalTargets extends NutrientVector {
  fiberGMin: number;
  sodiumMgMax: number;
  potassiumMgMax?: number;
  phosphorusMgMax?: number;
  cholesterolMgMax?: number;
  saturatedFatGMax?: number;
  sugarGMax?: number;
  fluidMlTarget?: number;
  giPreferredMax?: number;
}

export interface DayPlan {
  dayName: string;
  meals: MealPlan[];
  dailyTargets: ClinicalTargets;
  totals: NutrientVector;
}

export interface WeeklyTherapeuticPlan {
  diagnosis: string;
  clinicalAlignmentScore: number;
  constraints: TherapeuticConstraints;
  days: DayPlan[];
  standards: HospitalMenusStandards;
  notes: string[];
  rationale: string;
  preparedBy: string;
  updatedDate: string;
  approvalSignatureHash?: string;
  compoundDietCodes?: string[];
  validationReport?: {
    passed: boolean;
    issues: string[];
  };
}

export enum DiagnosisType {
  CARDIAC = "CARDIAC",
  RENAL = "RENAL",
  MSD = "MSD",
  DIABETIC = "DIABETIC",
  GASTRIC = "GASTRIC",
  LOW_FAT = "LOW FAT",
  SALT_FREE = "SALT FREE",
  LOW_FIBRE = "LOW FIBRE",
  ONCOLOGY = "ONCOLOGY",
  ULCER = "PEPTIC ULCER",
  PRENATAL = "PRE-NATAL",
  POSTNATAL = "POST-NATAL",
  LACTATION = "BREASTFEEDING",
  H_PYLORI = "H. PYLORI",
  HEPATIC = "HEPATIC",
  DYSPHAGIA = "DYSPHAGIA",
  NEUTROPENIC = "NEUTROPENIC",
  POST_OP = "POST-OPERATIVE",
  GERIATRIC = "GERIATRIC",
  CUSTOM = "CUSTOM"
}
