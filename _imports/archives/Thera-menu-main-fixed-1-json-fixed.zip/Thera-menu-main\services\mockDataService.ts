import { WeeklyTherapeuticPlan, DiagnosisType, MealSlot, DayPlan, MealPlan, ClinicalTargets, NutrientVector } from '../types';
import { getClinicalRules } from './clinicalDatabase';
import type { WeeklyPlan, DailyPlan as EngineDailyPlan, MealPlan as EngineMealPlan } from './clinicalEngine';
import { validateWeeklyPlan } from './validationService';

const HOT_FOOD_CATEGORIES = new Set(['protein', 'grain', 'starch', 'vegetable', 'broth']);

function toDisplayDiagnosis(diagnosis: string): string {
  return diagnosis || DiagnosisType.CUSTOM;
}

function inferServiceTemp(category: string | undefined, mealType: string): string {
  if (category && HOT_FOOD_CATEGORIES.has(category)) return '>= 60°C';
  if (mealType.toLowerCase().includes('breakfast')) return '>= 60°C';
  return '<= 8°C';
}

function humanizeMealType(mealType: string): MealPlan['mealType'] {
  if (mealType === 'breakfast') return 'Breakfast';
  if (mealType === 'lunch') return 'Lunch';
  return 'Dinner';
}

function getDietaryLabel(diagnosis: string, mealType: string): string {
  return `${diagnosis} - ${humanizeMealType(mealType).toUpperCase()}`;
}

function toClinicalTargets(targets: any): ClinicalTargets {
  return {
    caloriesKcal: targets.caloriesKcal ?? 0,
    carbsG: targets.carbsG ?? 0,
    proteinG: targets.proteinG ?? 0,
    fatG: targets.fatG ?? 0,
    fiberG: targets.fiberG ?? 0,
    sodiumMg: targets.sodiumMg ?? 0,
    potassiumMg: targets.potassiumMg ?? 0,
    phosphorusMg: targets.phosphorusMg ?? 0,
    cholesterolMg: targets.cholesterolMg ?? 0,
    saturatedFatG: targets.saturatedFatG ?? 0,
    sugarG: targets.sugarG ?? 0,
    fluidMl: targets.fluidMl ?? 0,
    fiberGMin: targets.fiberGMin ?? targets.fiberG ?? 0,
    sodiumMgMax: targets.sodiumMgMax ?? targets.sodiumMg ?? 0,
    potassiumMgMax: targets.potassiumMgMax,
    phosphorusMgMax: targets.phosphorusMgMax,
    cholesterolMgMax: targets.cholesterolMgMax,
    saturatedFatGMax: targets.saturatedFatGMax,
    sugarGMax: targets.sugarGMax,
    fluidMlTarget: targets.fluidMlTarget ?? targets.fluidMl,
    giPreferredMax: targets.giPreferredMax,
  };
}

function toNutrientVector(totals: any): NutrientVector {
  return {
    caloriesKcal: totals.caloriesKcal ?? 0,
    carbsG: totals.carbsG ?? 0,
    proteinG: totals.proteinG ?? 0,
    fatG: totals.fatG ?? 0,
    fiberG: totals.fiberG ?? 0,
    sodiumMg: totals.sodiumMg ?? 0,
    potassiumMg: totals.potassiumMg ?? 0,
    phosphorusMg: totals.phosphorusMg ?? 0,
    cholesterolMg: totals.cholesterolMg ?? 0,
    saturatedFatG: totals.saturatedFatG ?? 0,
    sugarG: totals.sugarG ?? 0,
    fluidMl: totals.fluidMl ?? 0,
  };
}

function buildSlots(engineMeal: EngineMealPlan, diagnosis: string): MealSlot[] {
  const rules = getClinicalRules(diagnosis);
  const slotDefs = engineMeal.mealType === 'breakfast' ? rules.slots.breakfast : engineMeal.mealType === 'lunch' ? rules.slots.lunch : rules.slots.dinner;

  return slotDefs.map((slotDef, index) => {
    const sourceItem = engineMeal.items[index] ?? engineMeal.items[engineMeal.items.length - 1];
    const categoryHint = sourceItem?.foodName?.toLowerCase().includes('broth') ? 'broth' : undefined;

    return {
      slotName: slotDef.name,
      status: sourceItem ? 'FILLED' : 'EMPTY',
      item: sourceItem
        ? {
            name: sourceItem.foodName,
            portion: `${sourceItem.quantity}${sourceItem.unit}`,
            minPortion: slotDef.portion_guideline,
            maxPortion: slotDef.portion_guideline,
            therapeuticOverride: diagnosis === DiagnosisType.DYSPHAGIA ? 'Texture-modified per IDDSI requirements' : undefined,
            operational: {
              hotHoldingTemp: rules.operational_standards.hot_holding,
              coldHoldingTemp: rules.operational_standards.cold_holding,
              serviceTemp: inferServiceTemp(categoryHint, engineMeal.mealType),
              handlingNotes: 'Generated in local mock mode from deterministic clinical engine output.',
            },
          }
        : null,
    };
  });
}

function buildMeal(engineMeal: EngineMealPlan, diagnosis: string): MealPlan {
  return {
    mealType: humanizeMealType(engineMeal.mealType),
    dietaryLabel: getDietaryLabel(diagnosis, engineMeal.mealType),
    slots: buildSlots(engineMeal, diagnosis),
  };
}

function buildDay(day: EngineDailyPlan, diagnosis: string): DayPlan {
  const mainMeals = day.meals.filter((meal) => ['breakfast', 'lunch', 'dinner'].includes(meal.mealType));

  return {
    dayName: `Day ${day.dayNumber}`,
    dailyTargets: toClinicalTargets(day.dailyTargets),
    totals: toNutrientVector(day.totals),
    meals: mainMeals.map((meal) => buildMeal(meal, diagnosis)),
  };
}

export function buildMockWeeklyPlan(enginePlan: WeeklyPlan, diagnosis: string, patientDetails?: string): WeeklyTherapeuticPlan {
  const rules = getClinicalRules(diagnosis);

  const plan: WeeklyTherapeuticPlan = {
    diagnosis: toDisplayDiagnosis(diagnosis),
    clinicalAlignmentScore: 92,
    constraints: {
      exclude: rules.forbidden_tags,
      prioritize: [rules.therapeutic_goal, ...rules.cooking_methods].slice(0, 4),
      textureLevel: enginePlan.patient.textureLevel,
      nutrientTargets: `Energy ${enginePlan.days[0]?.dailyTargets.caloriesKcal ?? 0} kcal/day, sodium max ${enginePlan.days[0]?.dailyTargets.sodiumMgMax ?? 0} mg/day`,
    },
    days: enginePlan.days.map((day) => buildDay(day, diagnosis)),
    standards: {
      hotHolding: rules.operational_standards.hot_holding,
      servingHotFood: rules.operational_standards.serving_hot,
      coldHolding: rules.operational_standards.cold_holding,
      servingColdFood: rules.operational_standards.serving_cold,
      boosting: 'Use fortified snacks or supplements only after dietitian review.',
      vehicle: 'Local mock mode does not validate transport equipment; treat as demo data.',
      standardsList: [
        { key: 'hot_holding', operator: '>=', value: 63, unit: '°C', note: 'Hospital hot-hold threshold' },
        { key: 'cold_holding', operator: '<=', value: 5, unit: '°C', note: 'Hospital cold-hold threshold' },
      ],
    },
    notes: [
      'Generated without Gemini API using deterministic local mock mode.',
      patientDetails ? `Patient details: ${patientDetails}` : 'No free-text patient notes supplied.',
      'Use this output for UI development and API contract testing only.',
    ],
    rationale: `${rules.therapeutic_goal} This mock plan preserves the app contract while offline.`,
    preparedBy: 'TheraMenu Local Mock Engine',
    updatedDate: new Date().toISOString(),
    validationReport: { passed: true, issues: [] },
  };

  const validation = validateWeeklyPlan(plan);
  plan.validationReport = validation;
  if (!validation.passed) {
    plan.clinicalAlignmentScore = Math.max(0, plan.clinicalAlignmentScore - validation.issues.length * 5);
  }

  return plan;
}

export function buildMockChatResponse(message: string): string {
  return [
    'Local mock mode is active, so this response is deterministic rather than model-generated.',
    `Question received: ${message}`,
    'Use the Generator tab to test end-to-end UI flows without a Gemini key.',
    'When ready for live inference, add GEMINI_API_KEY to .env.local and disable VITE_USE_MOCK_DATA.',
  ].join('\n\n');
}
