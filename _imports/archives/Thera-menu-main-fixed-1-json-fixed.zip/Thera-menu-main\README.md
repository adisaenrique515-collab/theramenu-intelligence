<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# TheraMenu local development

This app can now run in two modes:

- **Mock mode** for local UI and API-contract development without Gemini
- **Live Gemini mode** for real inference

## 1) Install

```bash
npm install
```

## 2) Create `.env.local`

### Mock mode
```env
VITE_USE_MOCK_DATA=true
```

### Live Gemini mode
```env
GEMINI_API_KEY=your_key_here
VITE_USE_MOCK_DATA=false
```

## 3) Run locally

```bash
npm run dev
```

Open the app at `http://localhost:3000`.

## Notes

- In mock mode, the app uses the deterministic clinical engine to build a contract-safe weekly plan.
- Chatbot responses also fall back to a local stub in mock mode.
- This is enough to finish front-end flows, mock APIs, and UI validation before wiring live Gemini.

## Build

```bash
npm run build
```

## Type check

```bash
npm run lint
```
