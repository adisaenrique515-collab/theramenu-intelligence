
import { GoogleGenAI, Type } from "@google/genai";
import { WeeklyTherapeuticPlan } from "../types";
import { getClinicalRules } from "./clinicalDatabase";
import { validateWeeklyPlan } from "./validationService";
import { buildMockChatResponse, buildMockWeeklyPlan } from "./mockDataService";

export async function transformMenu(
  originalMenu: string,
  diagnosis: string,
  patientDetails?: string
): Promise<WeeklyTherapeuticPlan> {
  const useMockData = import.meta.env.VITE_USE_MOCK_DATA === 'true' || !process.env.GEMINI_API_KEY;

  if (useMockData) {
    const enginePlan = JSON.parse(originalMenu);
    return buildMockWeeklyPlan(enginePlan, diagnosis, patientDetails);
  }

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const clinicalRules = getClinicalRules(diagnosis);

  const prompt = `
    ACT AS A HOSPITAL CLINICAL DIETETIC ENGINE (Tier 1 Medical Grade).
    
    CONTEXT:
    You are generating a 7-DAY THERAPEUTIC HOSPITAL MENU for a patient with: ${diagnosis}.
    This is a "Medical Nutrition Therapy" (MNT) document, not a restaurant menu.
    
    THERAPEUTIC GOAL: ${clinicalRules.therapeutic_goal}
    
    STRICT CLINICAL RULES (DATABASE ENFORCED):
    - ALLOWED PROTEIN CLASSES: ${clinicalRules.allowed_proteins.join(', ')}
    - ALLOWED STARCH CLASSES: ${clinicalRules.allowed_starches.join(', ')}
    - ALLOWED VEGETABLE CLASSES: ${clinicalRules.allowed_vegetables.join(', ')}
    - ALLOWED FRUIT CLASSES: ${clinicalRules.allowed_fruits?.join(', ') || 'None'}
    - FORBIDDEN ATTRIBUTES (CONTRAINDICATIONS): ${clinicalRules.forbidden_tags.join(', ')}
    - REQUIRED COOKING METHODS: ${clinicalRules.cooking_methods.join(', ')}
    - FLUID REQUIREMENT: ${clinicalRules.fluid_requirement}
    
    PORTION LOGIC (GRAMS REQUIRED):
    - Protein: ${clinicalRules.portion_rules.protein}
    - Starch: ${clinicalRules.portion_rules.starch}
    - Vegetable: ${clinicalRules.portion_rules.veg}
    - Fruit: ${clinicalRules.portion_rules.fruit || 'N/A'}

    MEAL SLOT DEFINITIONS (YOU MUST FILL THESE EXACT SLOTS):
    - BREAKFAST: ${JSON.stringify(clinicalRules.slots.breakfast)}
    - LUNCH: ${JSON.stringify(clinicalRules.slots.lunch)}
    - DINNER: ${JSON.stringify(clinicalRules.slots.dinner)}

    OPERATIONAL STANDARDS (APPLY TO ITEMS):
    - Hot Holding: ${clinicalRules.operational_standards.hot_holding}
    - Cold Holding: ${clinicalRules.operational_standards.cold_holding}
    - Serving Hot: ${clinicalRules.operational_standards.serving_hot}
    - Serving Cold: ${clinicalRules.operational_standards.serving_cold}

    TASK:
    Construct a 7-day therapeutic menu by FILLING THE DEFINED SLOTS for each meal.
    Use the provided Clinical Plan (JSON) as the source of truth for items and nutritional totals.
    
    CRITICAL INSTRUCTIONS:
    1. SLOT-BASED ASSEMBLY: Do not invent meals. Fill the specific slots (e.g., "Base Carbohydrate", "Protein") defined above.
    2. SELECT ONLY from the Allowed Classes. Do not invent ingredients outside this list unless they are strictly compliant.
    3. APPLY the Portion Logic strictly. Every serving size MUST be in grams (e.g., "120g", "150g").
    4. VALIDATE against Forbidden Attributes. (e.g., If Gastric, NO SPICE, NO FRYING).
    5. OPERATIONAL METADATA: For each item, assign the correct holding/service temperature based on the food type (Hot vs Cold). EVERY item MUST have a serviceTemp (e.g., ">= 60°C" for hot, "<= 8°C" for cold). Do not leave it blank for beverages or fruits.
    6. NUTRITIONAL TOTALS: You MUST include the 'dailyTargets' and 'totals' for each day exactly as they appear in the input Clinical Plan.

    INPUT CLINICAL PLAN:
    ${originalMenu}

    OUTPUT STRUCTURE:
    Return a JSON object matching the WeeklyTherapeuticPlan interface.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          diagnosis: { type: Type.STRING },
          clinicalAlignmentScore: { type: Type.NUMBER },
          approvalSignatureHash: { type: Type.STRING },
          compoundDietCodes: { type: Type.ARRAY, items: { type: Type.STRING } },
          constraints: {
            type: Type.OBJECT,
            properties: {
              exclude: { type: Type.ARRAY, items: { type: Type.STRING } },
              prioritize: { type: Type.ARRAY, items: { type: Type.STRING } },
              textureLevel: { type: Type.STRING },
              nutrientTargets: { type: Type.STRING }
            },
            required: ["exclude", "prioritize", "textureLevel"]
          },
          days: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                dayName: { type: Type.STRING },
                dailyTargets: {
                  type: Type.OBJECT,
                  properties: {
                    caloriesKcal: { type: Type.NUMBER },
                    carbsG: { type: Type.NUMBER },
                    proteinG: { type: Type.NUMBER },
                    fatG: { type: Type.NUMBER },
                    sodiumMg: { type: Type.NUMBER }
                  },
                  required: ["caloriesKcal", "carbsG", "proteinG", "fatG", "sodiumMg"]
                },
                totals: {
                  type: Type.OBJECT,
                  properties: {
                    caloriesKcal: { type: Type.NUMBER },
                    carbsG: { type: Type.NUMBER },
                    proteinG: { type: Type.NUMBER },
                    fatG: { type: Type.NUMBER },
                    sodiumMg: { type: Type.NUMBER }
                  },
                  required: ["caloriesKcal", "carbsG", "proteinG", "fatG", "sodiumMg"]
                },
                meals: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      mealType: { type: Type.STRING },
                      dietaryLabel: { type: Type.STRING },
                      slots: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            slotName: { type: Type.STRING },
                            status: { type: Type.STRING, enum: ["FILLED", "EMPTY", "SUBSTITUTED"] },
                            item: {
                              type: Type.OBJECT,
                              properties: {
                                name: { type: Type.STRING },
                                portion: { type: Type.STRING },
                                minPortion: { type: Type.STRING },
                                maxPortion: { type: Type.STRING },
                                therapeuticOverride: { type: Type.STRING },
                                operational: {
                                  type: Type.OBJECT,
                                  properties: {
                                    hotHoldingTemp: { type: Type.STRING },
                                    coldHoldingTemp: { type: Type.STRING },
                                    serviceTemp: { type: Type.STRING },
                                    handlingNotes: { type: Type.STRING }
                                  },
                                  required: ["serviceTemp"]
                                }
                              },
                              required: ["name", "portion", "operational"]
                            }
                          },
                          required: ["slotName", "status", "item"]
                        }
                      }
                    },
                    required: ["mealType", "slots", "dietaryLabel"]
                  }
                }
              },
              required: ["dayName", "meals", "dailyTargets", "totals"]
            }
          },
          standards: {
            type: Type.OBJECT,
            properties: {
              hotHolding: { type: Type.STRING },
              servingHotFood: { type: Type.STRING },
              coldHolding: { type: Type.STRING },
              servingColdFood: { type: Type.STRING },
              boosting: { type: Type.STRING },
              vehicle: { type: Type.STRING },
              standardsList: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    key: { type: Type.STRING },
                    operator: { type: Type.STRING },
                    value: { type: Type.NUMBER },
                    unit: { type: Type.STRING },
                    note: { type: Type.STRING }
                  },
                  required: ["key", "operator", "value", "unit"]
                }
              }
            }
          },
          notes: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          rationale: { type: Type.STRING },
          preparedBy: { type: Type.STRING },
          updatedDate: { type: Type.STRING },
          validationReport: {
            type: Type.OBJECT,
            properties: {
              passed: { type: Type.BOOLEAN },
              issues: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
          }
        },
        required: ["diagnosis", "days", "rationale", "clinicalAlignmentScore", "constraints"]
      }
    }
  });

  if (!response.text) {
    throw new Error("Empty response from clinical intelligence engine.");
  }

  let generatedPlan: WeeklyTherapeuticPlan;
  try {
    generatedPlan = JSON.parse(response.text) as WeeklyTherapeuticPlan;
  } catch (e) {
    console.error("Failed to parse clinical plan:", response.text);
    throw new Error("The intelligence engine returned an invalid data format. Please try again.");
  }

  // Run Post-Assembly Validation
  const validationResult = validateWeeklyPlan(generatedPlan);
  generatedPlan.validationReport = validationResult;

  // Adjust score if validation failed
  if (!validationResult.passed) {
    // Deduct 5% for each issue found, but don't go below 0
    generatedPlan.clinicalAlignmentScore = Math.max(0, generatedPlan.clinicalAlignmentScore - (validationResult.issues.length * 5));
  }

  return generatedPlan;
}

export async function chatWithDietitian(message: string, history: any[] = []) {
  const useMockData = import.meta.env.VITE_USE_MOCK_DATA === 'true' || !process.env.GEMINI_API_KEY;

  if (useMockData) {
    return buildMockChatResponse(message);
  }

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const chat = ai.chats.create({
    model: "gemini-3.1-pro-preview",
    config: {
      systemInstruction: "You are a Clinical Dietitian expert for TheraMenu. You help users with hospital dietary protocols, IDDSI levels, and therapeutic meal planning. Be professional, clinical, and helpful.",
    },
  });

  const response = await chat.sendMessage({ message });
  return response.text;
}
